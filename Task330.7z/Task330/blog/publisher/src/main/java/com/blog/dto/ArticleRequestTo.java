package com.blog.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ArticleRequestTo {

    private Long id; // For update operations

    @NotNull(message = "Writer ID cannot be null")
    private Long writerId;

    @NotBlank(message = "Title cannot be blank")
    @Size(min = 1, max = 200, message = "Title must be between 1 and 200 characters")
    private String title;

    @NotBlank(message = "Content cannot be blank")
    @Size(min = 1, message = "Content cannot be empty")
    private String content;
}