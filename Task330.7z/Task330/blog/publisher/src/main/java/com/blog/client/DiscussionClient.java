package com.blog.client;

import com.blog.dto.ReactionRequestTo;
import com.blog.dto.ReactionResponseTo;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.Arrays;
import java.util.List;

@Component
public class DiscussionClient {

    private final RestClient restClient;
    private static final String DISCUSSION_BASE_URL = "http://localhost:24130/api/v1.0";

    public DiscussionClient(RestClient.Builder restClientBuilder) {
        this.restClient = restClientBuilder
                .baseUrl(DISCUSSION_BASE_URL)
                .build();
    }

    public List<ReactionResponseTo> getAllReactions() {
        return Arrays.asList(restClient.get()
                .uri("/reactions")
                .retrieve()
                .body(ReactionResponseTo[].class));
    }

    public ReactionResponseTo getReactionById(String country, Long articleId, Long id) {
        return restClient.get()
                .uri("/reactions/{country}/{articleId}/{id}", country, articleId, id)
                .retrieve()
                .body(ReactionResponseTo.class);
    }

    public ReactionResponseTo getReactionByIdOnly(Long id) {
        return restClient.get()
                .uri("/reactions/{id}", id)
                .retrieve()
                .body(ReactionResponseTo.class);
    }

    public List<ReactionResponseTo> getReactionsByArticleId(Long articleId) {
        return Arrays.asList(restClient.get()
                .uri("/reactions/article/{articleId}", articleId)
                .retrieve()
                .body(ReactionResponseTo[].class));
    }

    public List<ReactionResponseTo> getReactionsByCountryAndArticleId(String country, Long articleId) {
        return Arrays.asList(restClient.get()
                .uri("/reactions/country/{country}/article/{articleId}", country, articleId)
                .retrieve()
                .body(ReactionResponseTo[].class));
    }

    public ReactionResponseTo createReaction(ReactionRequestTo request) {
        return restClient.post()
                .uri("/reactions")
                .body(request)
                .retrieve()
                .body(ReactionResponseTo.class);
    }

    public ReactionResponseTo updateReaction(String country, Long articleId, Long id, ReactionRequestTo request) {
        return restClient.put()
                .uri("/reactions/{country}/{articleId}/{id}", country, articleId, id)
                .body(request)
                .retrieve()
                .body(ReactionResponseTo.class);
    }

    public ReactionResponseTo updateReactionFromBody(ReactionRequestTo request) {
        return restClient.put()
                .uri("/reactions")
                .body(request)
                .retrieve()
                .body(ReactionResponseTo.class);
    }

    public void deleteReaction(String country, Long articleId, Long id) {
        restClient.delete()
                .uri("/reactions/{country}/{articleId}/{id}", country, articleId, id)
                .retrieve()
                .toBodilessEntity();
    }

    public void deleteReactionByIdOnly(Long id) {
        restClient.delete()
                .uri("/reactions/{id}", id)
                .retrieve()
                .toBodilessEntity();
    }
}