package com.blog.client;

import com.blog.dto.ReactionRequestTo;
import com.blog.dto.ReactionResponseTo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestClient;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class DiscussionClientTest {

    private RestClient restClient;
    private RestClient.Builder restClientBuilder;
    private DiscussionClient discussionClient;

    @BeforeEach
    void setUp() {
        restClient = mock(RestClient.class);
        restClientBuilder = mock(RestClient.Builder.class);
        when(restClientBuilder.baseUrl(anyString())).thenReturn(restClientBuilder);
        when(restClientBuilder.build()).thenReturn(restClient);

        discussionClient = new DiscussionClient(restClientBuilder);
    }

    @Test
    void getAllReactions_ShouldReturnReactionsList() {
        // Given
        RestClient.RequestHeadersUriSpec requestSpec = mock(RestClient.RequestHeadersUriSpec.class);
        RestClient.ResponseSpec responseSpec = mock(RestClient.ResponseSpec.class);

        ReactionResponseTo[] reactions = {createSampleReaction()};
        when(restClient.get()).thenReturn(requestSpec);
        when(requestSpec.uri(anyString())).thenReturn(requestSpec);
        when(requestSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.body(ReactionResponseTo[].class)).thenReturn(reactions);

        // When
        List<ReactionResponseTo> result = discussionClient.getAllReactions();

        // Then
        assertEquals(1, result.size());
        verify(restClient).get();
        verify(requestSpec).uri("/reactions");
    }

    @Test
    void getReactionById_ShouldReturnReaction() {
        // Given
        RestClient.RequestHeadersUriSpec requestSpec = mock(RestClient.RequestHeadersUriSpec.class);
        RestClient.ResponseSpec responseSpec = mock(RestClient.ResponseSpec.class);

        ReactionResponseTo reaction = createSampleReaction();
        when(restClient.get()).thenReturn(requestSpec);
        when(requestSpec.uri(anyString(), any(), any(), any())).thenReturn(requestSpec);
        when(requestSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.body(ReactionResponseTo.class)).thenReturn(reaction);

        // When
        ReactionResponseTo result = discussionClient.getReactionById("US", 1L, 1L);

        // Then
        assertNotNull(result);
        assertEquals("US", result.getCountry());
        verify(restClient).get();
        verify(requestSpec).uri("/reactions/{country}/{articleId}/{id}", "US", 1L, 1L);
    }

    @Test
    void createReaction_ShouldReturnCreatedReaction() {
        // Given
        RestClient.RequestBodyUriSpec requestSpec = mock(RestClient.RequestBodyUriSpec.class);
        RestClient.RequestBodySpec bodySpec = mock(RestClient.RequestBodySpec.class);
        RestClient.ResponseSpec responseSpec = mock(RestClient.ResponseSpec.class);

        ReactionRequestTo request = new ReactionRequestTo("US", 1L, "Test content");
        ReactionResponseTo response = createSampleReaction();

        when(restClient.post()).thenReturn(requestSpec);
        when(requestSpec.uri(anyString())).thenReturn(bodySpec);
        when(bodySpec.body(any())).thenReturn(bodySpec);
        when(bodySpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.body(ReactionResponseTo.class)).thenReturn(response);

        // When
        ReactionResponseTo result = discussionClient.createReaction(request);

        // Then
        assertNotNull(result);
        verify(restClient).post();
        verify(requestSpec).uri("/reactions");
        verify(bodySpec).body(request);
    }

    @Test
    void updateReaction_ShouldReturnUpdatedReaction() {
        // Given
        RestClient.RequestBodyUriSpec requestSpec = mock(RestClient.RequestBodyUriSpec.class);
        RestClient.RequestBodySpec bodySpec = mock(RestClient.RequestBodySpec.class);
        RestClient.ResponseSpec responseSpec = mock(RestClient.ResponseSpec.class);

        ReactionRequestTo request = new ReactionRequestTo("US", 1L, "Updated content");
        ReactionResponseTo response = createSampleReaction();

        when(restClient.put()).thenReturn(requestSpec);
        when(requestSpec.uri(anyString(), any(), any(), any())).thenReturn(bodySpec);
        when(bodySpec.body(any())).thenReturn(bodySpec);
        when(bodySpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.body(ReactionResponseTo.class)).thenReturn(response);

        // When
        ReactionResponseTo result = discussionClient.updateReaction("US", 1L, 1L, request);

        // Then
        assertNotNull(result);
        verify(restClient).put();
        verify(requestSpec).uri("/reactions/{country}/{articleId}/{id}", "US", 1L, 1L);
    }

    @Test
    void deleteReaction_ShouldCallDelete() {
        // Given
        RestClient.RequestHeadersUriSpec requestSpec = mock(RestClient.RequestHeadersUriSpec.class);
        RestClient.RequestHeadersSpec headersSpec = mock(RestClient.RequestHeadersSpec.class);
        RestClient.ResponseSpec responseSpec = mock(RestClient.ResponseSpec.class);

        when(restClient.delete()).thenReturn(requestSpec);
        when(requestSpec.uri(anyString(), any(), any(), any())).thenReturn(headersSpec);
        when(headersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toBodilessEntity()).thenReturn(null);

        // When
        discussionClient.deleteReaction("US", 1L, 1L);

        // Then
        verify(restClient).delete();
        verify(requestSpec).uri("/reactions/{country}/{articleId}/{id}", "US", 1L, 1L);
    }

    private ReactionResponseTo createSampleReaction() {
        return new ReactionResponseTo("US", 1L, 1L, "Test content",
                LocalDateTime.now(), LocalDateTime.now());
    }
}