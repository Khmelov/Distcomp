package com.blog.repository;

import com.blog.entity.Reaction;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReactionRepository extends CassandraRepository<Reaction, Reaction.ReactionKey> {

    @Query("SELECT * FROM tbl_reaction WHERE country = ?0 AND article_id = ?1 ALLOW FILTERING")
    List<Reaction> findByCountryAndArticleId(String country, Long articleId);

    @Query("SELECT * FROM tbl_reaction WHERE article_id = ?0 ALLOW FILTERING")
    List<Reaction> findByArticleId(Long articleId);

    @Query("SELECT * FROM tbl_reaction WHERE country = ?0 ALLOW FILTERING")
    List<Reaction> findByCountry(String country);
}