package com.blog.controller;

import com.blog.dto.ReactionRequestTo;
import com.blog.dto.ReactionResponseTo;
import com.blog.service.ReactionService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1.0/reactions")
public class ReactionController {

    private final ReactionService reactionService;

    public ReactionController(ReactionService reactionService) {
        this.reactionService = reactionService;
    }

    @GetMapping
    public ResponseEntity<List<ReactionResponseTo>> getAllReactions() {
        List<ReactionResponseTo> reactions = reactionService.findAll();
        return ResponseEntity.ok(reactions);
    }

    @GetMapping("/{country}/{articleId}/{id}")
    public ResponseEntity<ReactionResponseTo> getReactionById(@PathVariable String country,
                                                              @PathVariable Long articleId,
                                                              @PathVariable Long id) {
        ReactionResponseTo reaction = reactionService.findById(country, articleId, id);
        return ResponseEntity.ok(reaction);
    }

    // Alternative endpoint for compatibility with publisher service
    @GetMapping("/{id}")
    public ResponseEntity<ReactionResponseTo> getReactionByIdOnly(@PathVariable Long id) {
        // Find reaction by id across all countries/articles
        List<ReactionResponseTo> allReactions = reactionService.findAll();
        ReactionResponseTo reaction = allReactions.stream()
                .filter(r -> r.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Reaction not found with id: " + id));
        return ResponseEntity.ok(reaction);
    }

    @GetMapping("/article/{articleId}")
    public ResponseEntity<List<ReactionResponseTo>> getReactionsByArticleId(@PathVariable Long articleId) {
        List<ReactionResponseTo> reactions = reactionService.findByArticleId(articleId);
        return ResponseEntity.ok(reactions);
    }

    @GetMapping("/country/{country}/article/{articleId}")
    public ResponseEntity<List<ReactionResponseTo>> getReactionsByCountryAndArticleId(@PathVariable String country,
                                                                                       @PathVariable Long articleId) {
        List<ReactionResponseTo> reactions = reactionService.findByCountryAndArticleId(country, articleId);
        return ResponseEntity.ok(reactions);
    }

    @PostMapping
    public ResponseEntity<ReactionResponseTo> createReaction(@Valid @RequestBody ReactionRequestTo request) {
        ReactionResponseTo createdReaction = reactionService.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdReaction);
    }

    @PutMapping("/{country}/{articleId}/{id}")
    public ResponseEntity<ReactionResponseTo> updateReaction(@PathVariable String country,
                                                             @PathVariable Long articleId,
                                                             @PathVariable Long id,
                                                             @Valid @RequestBody ReactionRequestTo request) {
        ReactionResponseTo updatedReaction = reactionService.update(country, articleId, id, request);
        return ResponseEntity.ok(updatedReaction);
    }

    // Alternative endpoint for compatibility with publisher service
    @PutMapping
    public ResponseEntity<ReactionResponseTo> updateReactionFromBody(@Valid @RequestBody ReactionRequestTo request) {
        // Publisher sends ID in request body
        if (request.getId() == null || request.getCountry() == null || request.getArticleId() == null) {
            return ResponseEntity.badRequest().build();
        }
        ReactionResponseTo updatedReaction = reactionService.update(request.getCountry(), request.getArticleId(), request.getId(), request);
        return ResponseEntity.ok(updatedReaction);
    }

    @DeleteMapping("/{country}/{articleId}/{id}")
    public ResponseEntity<Void> deleteReaction(@PathVariable String country,
                                               @PathVariable Long articleId,
                                               @PathVariable Long id) {
        reactionService.deleteById(country, articleId, id);
        return ResponseEntity.noContent().build();
    }

    // Alternative endpoint for compatibility with publisher service
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteReactionByIdOnly(@PathVariable Long id) {
        // Find reaction by id across all countries/articles and delete it
        List<ReactionResponseTo> allReactions = reactionService.findAll();
        ReactionResponseTo reaction = allReactions.stream()
                .filter(r -> r.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Reaction not found with id: " + id));

        reactionService.deleteById(reaction.getCountry(), reaction.getArticleId(), id);
        return ResponseEntity.noContent().build();
    }
}