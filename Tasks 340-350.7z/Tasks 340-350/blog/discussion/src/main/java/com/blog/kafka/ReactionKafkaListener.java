package com.blog.kafka;

import com.blog.dto.ReactionRequestTo;
import com.blog.dto.ReactionResponseTo;
import com.blog.exception.EntityNotFoundException;
import com.blog.service.ReactionService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ReactionKafkaListener {

    private final ReactionService reactionService;
    private final KafkaTemplate<String, ReactionKafkaResponse> kafkaTemplate;
    private final String outTopic;

    public ReactionKafkaListener(
            ReactionService reactionService,
            KafkaTemplate<String, ReactionKafkaResponse> kafkaTemplate,
            @Value("${app.kafka.out-topic:OutTopic}") String outTopic
    ) {
        this.reactionService = reactionService;
        this.kafkaTemplate = kafkaTemplate;
        this.outTopic = outTopic;
    }

    @KafkaListener(topics = "${app.kafka.in-topic:InTopic}", groupId = "${spring.kafka.consumer.group-id:discussion}")
    public void onRequest(ReactionKafkaRequest request) {
        if (request == null) {
            return;
        }

        ReactionKafkaResponse response = new ReactionKafkaResponse();
        response.setCorrelationId(request.getCorrelationId());
        response.setOperation(request.getOperation());

        try {
            handle(request, response);
            response.setSuccess(true);
        } catch (EntityNotFoundException ex) {
            response.setSuccess(false);
            response.setErrorCode("ENTITY_NOT_FOUND");
            response.setErrorMessage(ex.getMessage());
        } catch (IllegalArgumentException ex) {
            response.setSuccess(false);
            response.setErrorCode("BAD_REQUEST");
            response.setErrorMessage(ex.getMessage());
        } catch (Exception ex) {
            response.setSuccess(false);
            response.setErrorCode("INTERNAL_ERROR");
            response.setErrorMessage("Internal server error");
        }

        kafkaTemplate.send(outTopic, keyForArticle(request.getArticleId()), response);
    }

    private void handle(ReactionKafkaRequest request, ReactionKafkaResponse response) {
        if (request.getOperation() == null) {
            throw new IllegalArgumentException("Operation is required");
        }

        switch (request.getOperation()) {
            case CREATE -> {
                ReactionRequestTo reaction = requireReaction(request);
                normalize(reaction, request);

                reaction.setStatus(moderateStatus(reaction.getContent()));
                ReactionResponseTo created = reactionService.create(reaction);
                response.setReaction(created);
            }
            case UPDATE -> {
                ReactionRequestTo reaction = requireReaction(request);
                normalize(reaction, request);

                reaction.setStatus(moderateStatus(reaction.getContent()));

                ReactionResponseTo updated = reactionService.update(
                        requireString(request.getCountry(), "country"),
                        requireLong(request.getArticleId(), "articleId"),
                        requireLong(request.getId(), "id"),
                        reaction
                );
                response.setReaction(updated);
            }
            case DELETE -> {
                reactionService.deleteById(
                        requireString(request.getCountry(), "country"),
                        requireLong(request.getArticleId(), "articleId"),
                        requireLong(request.getId(), "id")
                );
            }
            case DELETE_BY_ID_ONLY -> {
                Long id = requireLong(request.getId(), "id");
                ReactionResponseTo existing = findByIdOnly(id);
                reactionService.deleteById(existing.getCountry(), existing.getArticleId(), id);
            }
            case GET_ALL -> response.setReactions(reactionService.findAll());
            case GET_BY_KEY -> response.setReaction(reactionService.findById(
                    requireString(request.getCountry(), "country"),
                    requireLong(request.getArticleId(), "articleId"),
                    requireLong(request.getId(), "id")
            ));
            case GET_BY_ID_ONLY -> response.setReaction(findByIdOnly(requireLong(request.getId(), "id")));
            case GET_BY_ARTICLE_ID -> response.setReactions(reactionService.findByArticleId(requireLong(request.getArticleId(), "articleId")));
            case GET_BY_COUNTRY_AND_ARTICLE_ID -> response.setReactions(reactionService.findByCountryAndArticleId(
                    requireString(request.getCountry(), "country"),
                    requireLong(request.getArticleId(), "articleId")
            ));
        }
    }

    private ReactionResponseTo findByIdOnly(Long id) {
        List<ReactionResponseTo> all = reactionService.findAll();
        return all.stream()
                .filter(r -> r.getId() != null && r.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new EntityNotFoundException("Reaction not found with id: " + id));
    }

    private ReactionRequestTo requireReaction(ReactionKafkaRequest request) {
        if (request.getReaction() == null) {
            throw new IllegalArgumentException("Reaction payload is required");
        }
        return request.getReaction();
    }

    private void normalize(ReactionRequestTo reaction, ReactionKafkaRequest request) {
        if (reaction.getCountry() == null) {
            reaction.setCountry(request.getCountry());
        }
        if (reaction.getArticleId() == null) {
            reaction.setArticleId(request.getArticleId());
        }
        if (reaction.getId() == null) {
            reaction.setId(request.getId());
        }
    }

    private Long requireLong(Long v, String name) {
        if (v == null) {
            throw new IllegalArgumentException(name + " is required");
        }
        return v;
    }

    private String requireString(String v, String name) {
        if (v == null || v.trim().isEmpty()) {
            throw new IllegalArgumentException(name + " is required");
        }
        return v;
    }

    private String moderateStatus(String content) {
        if (content == null) {
            return "APPROVE";
        }
        String lower = content.toLowerCase();
        if (lower.contains("spam") || lower.contains("bad") || lower.contains("forbidden")) {
            return "DECLINE";
        }
        return "APPROVE";
    }

    private String keyForArticle(Long articleId) {
        return articleId == null ? "0" : String.valueOf(articleId);
    }
}
