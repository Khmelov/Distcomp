package com.blog.service;

import com.blog.dto.ReactionRequestTo;
import com.blog.dto.ReactionResponseTo;
import com.blog.entity.Reaction;
import com.blog.exception.EntityNotFoundException;
import com.blog.mapper.ReactionMapper;
import com.blog.repository.ReactionRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReactionService {

    private final ReactionRepository reactionRepository;
    private final ReactionMapper reactionMapper;

    public ReactionService(ReactionRepository reactionRepository, ReactionMapper reactionMapper) {
        this.reactionRepository = reactionRepository;
        this.reactionMapper = reactionMapper;
    }

    public List<ReactionResponseTo> findAll() {
        return reactionRepository.findAll().stream()
                .map(reactionMapper::entityToResponseTo)
                .collect(Collectors.toList());
    }

    public ReactionResponseTo findById(String country, Long articleId, Long id) {
        Reaction.ReactionKey key = new Reaction.ReactionKey(country, articleId, id);
        Reaction reaction = reactionRepository.findById(key)
                .orElseThrow(() -> new EntityNotFoundException("Reaction not found with id: " + id + " for article: " + articleId + " in country: " + country));
        return reactionMapper.entityToResponseTo(reaction);
    }

    public ReactionResponseTo create(ReactionRequestTo request) {
        Reaction reaction = reactionMapper.requestToToEntity(request);

        // Generate ID - in Cassandra we need to handle ID generation manually
        if (request.getId() != null) {
            reaction.getKey().setId(request.getId());
        } else {
            Long nextId = getNextIdForArticle(request.getCountry(), request.getArticleId());
            reaction.getKey().setId(nextId);
        }

        reaction.setCreated(LocalDateTime.now());
        reaction.setModified(LocalDateTime.now());

        Reaction savedReaction = reactionRepository.save(reaction);
        return reactionMapper.entityToResponseTo(savedReaction);
    }

    public ReactionResponseTo update(String country, Long articleId, Long id, ReactionRequestTo request) {
        Reaction.ReactionKey key = new Reaction.ReactionKey(country, articleId, id);
        Reaction existingReaction = reactionRepository.findById(key)
                .orElseThrow(() -> new EntityNotFoundException("Reaction not found with id: " + id + " for article: " + articleId + " in country: " + country));

        reactionMapper.updateEntityFromRequest(request, existingReaction);
        existingReaction.setModified(LocalDateTime.now());

        Reaction updatedReaction = reactionRepository.save(existingReaction);
        return reactionMapper.entityToResponseTo(updatedReaction);
    }

    public void deleteById(String country, Long articleId, Long id) {
        Reaction.ReactionKey key = new Reaction.ReactionKey(country, articleId, id);
        if (!reactionRepository.existsById(key)) {
            throw new EntityNotFoundException("Reaction not found with id: " + id + " for article: " + articleId + " in country: " + country);
        }
        reactionRepository.deleteById(key);
    }

    public List<ReactionResponseTo> findByArticleId(Long articleId) {
        return reactionRepository.findByArticleId(articleId).stream()
                .map(reactionMapper::entityToResponseTo)
                .collect(Collectors.toList());
    }

    public List<ReactionResponseTo> findByCountryAndArticleId(String country, Long articleId) {
        return reactionRepository.findByCountryAndArticleId(country, articleId).stream()
                .map(reactionMapper::entityToResponseTo)
                .collect(Collectors.toList());
    }

    private Long getNextIdForArticle(String country, Long articleId) {
        // Find the maximum ID for the given country and articleId
        List<Reaction> reactions = reactionRepository.findByCountryAndArticleId(country, articleId);
        return reactions.stream()
                .mapToLong(reaction -> reaction.getKey().getId())
                .max()
                .orElse(0L) + 1;
    }
}