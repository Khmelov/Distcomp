package com.blog.kafka;

import com.blog.dto.ReactionRequestTo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReactionKafkaRequest {
    private String correlationId;
    private ReactionKafkaOperation operation;

    private String country;
    private Long articleId;
    private Long id;

    private ReactionRequestTo reaction;
}
