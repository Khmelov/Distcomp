package com.blog.mapper;

import com.blog.dto.ReactionRequestTo;
import com.blog.dto.ReactionResponseTo;
import com.blog.entity.Reaction;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface ReactionMapper {

    @Mapping(target = "key.country", source = "country")
    @Mapping(target = "key.articleId", source = "articleId")
    @Mapping(target = "key.id", ignore = true)
    @Mapping(target = "created", ignore = true)
    @Mapping(target = "modified", ignore = true)
    @Mapping(target = "status", source = "status")
    Reaction requestToToEntity(ReactionRequestTo request);

    @Mapping(target = "country", source = "key.country")
    @Mapping(target = "articleId", source = "key.articleId")
    @Mapping(target = "id", source = "key.id")
    @Mapping(target = "status", source = "status")
    ReactionResponseTo entityToResponseTo(Reaction entity);

    @Mapping(target = "created", ignore = true)
    @Mapping(target = "modified", ignore = true)
    @Mapping(target = "key.country", source = "country")
    @Mapping(target = "key.articleId", source = "articleId")
    @Mapping(target = "key.id", ignore = true)
    @Mapping(target = "status", source = "status")
    Reaction updateEntityFromRequest(ReactionRequestTo request, @MappingTarget Reaction entity);
}