package com.blog.kafka;

import com.blog.dto.ReactionResponseTo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReactionKafkaResponse {
    private String correlationId;
    private ReactionKafkaOperation operation;

    private boolean success;
    private String errorMessage;
    private String errorCode;

    private ReactionResponseTo reaction;
    private List<ReactionResponseTo> reactions;
}
