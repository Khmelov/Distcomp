package com.blog.kafka;

public enum ReactionKafkaOperation {
    CREATE,
    UPDATE,
    DELETE,
    DELETE_BY_ID_ONLY,
    GET_ALL,
    GET_BY_KEY,
    GET_BY_ID_ONLY,
    GET_BY_ARTICLE_ID,
    GET_BY_COUNTRY_AND_ARTICLE_ID
}
