package com.blog.service;

import com.blog.dto.ArticleRequestTo;
import com.blog.dto.ArticleResponseTo;
import com.blog.entity.Article;
import com.blog.entity.Writer;
import com.blog.exception.EntityNotFoundException;
import com.blog.mapper.ArticleMapper;
import com.blog.repository.ArticleRepository;
import com.blog.repository.WriterRepository;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ArticleService {

    private final ArticleRepository articleRepository;
    private final WriterRepository writerRepository;
    private final ArticleMapper articleMapper;

    public ArticleService(ArticleRepository articleRepository, WriterRepository writerRepository, ArticleMapper articleMapper) {
        this.articleRepository = articleRepository;
        this.writerRepository = writerRepository;
        this.articleMapper = articleMapper;
    }

    @Cacheable(cacheNames = "article.all")
    public List<ArticleResponseTo> findAll() {
        return articleRepository.findAll().stream()
                .map(articleMapper::entityToResponseTo)
                .collect(Collectors.toList());
    }

    @Cacheable(cacheNames = "article.byId", key = "#id")
    public ArticleResponseTo findById(Long id) {
        Article article = articleRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Article not found with id: " + id));
        return articleMapper.entityToResponseTo(article);
    }

    @Caching(
            put = @CachePut(cacheNames = "article.byId", key = "#result.id"),
            evict = @CacheEvict(cacheNames = "article.all", allEntries = true)
    )
    public ArticleResponseTo create(ArticleRequestTo request) {
        // Validate writer exists
        Writer writer = writerRepository.findById(request.getWriterId())
                .orElseThrow(() -> new EntityNotFoundException("Writer not found with id: " + request.getWriterId()));

        Article article = articleMapper.requestToToEntity(request);
        article.setWriter(writer);
        article.setCreated(java.time.LocalDateTime.now());
        article.setModified(java.time.LocalDateTime.now());

        Article savedArticle = articleRepository.save(article);
        return articleMapper.entityToResponseTo(savedArticle);
    }

    @Caching(
            put = @CachePut(cacheNames = "article.byId", key = "#id"),
            evict = @CacheEvict(cacheNames = "article.all", allEntries = true)
    )
    public ArticleResponseTo update(Long id, ArticleRequestTo request) {
        Article existingArticle = articleRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Article not found with id: " + id));

        // Validate writer exists
        Writer writer = writerRepository.findById(request.getWriterId())
                .orElseThrow(() -> new EntityNotFoundException("Writer not found with id: " + request.getWriterId()));

        articleMapper.updateEntityFromRequest(request, existingArticle);
        existingArticle.setWriter(writer);
        existingArticle.setModified(java.time.LocalDateTime.now());

        Article updatedArticle = articleRepository.save(existingArticle);
        return articleMapper.entityToResponseTo(updatedArticle);
    }

    @Caching(evict = {
            @CacheEvict(cacheNames = "article.byId", key = "#id"),
            @CacheEvict(cacheNames = "article.all", allEntries = true)
    })
    public void deleteById(Long id) {
        if (!articleRepository.existsById(id)) {
            throw new EntityNotFoundException("Article not found with id: " + id);
        }
        articleRepository.deleteById(id);
    }
}