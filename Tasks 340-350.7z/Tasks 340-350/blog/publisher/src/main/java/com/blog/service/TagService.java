package com.blog.service;

import com.blog.dto.TagRequestTo;
import com.blog.dto.TagResponseTo;
import com.blog.entity.Tag;
import com.blog.exception.EntityNotFoundException;
import com.blog.mapper.TagMapper;
import com.blog.repository.TagRepository;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TagService {

    private final TagRepository tagRepository;
    private final TagMapper tagMapper;

    public TagService(TagRepository tagRepository, TagMapper tagMapper) {
        this.tagRepository = tagRepository;
        this.tagMapper = tagMapper;
    }

    @Cacheable(cacheNames = "tag.all")
    public List<TagResponseTo> findAll() {
        return tagRepository.findAll().stream()
                .map(tagMapper::entityToResponseTo)
                .collect(Collectors.toList());
    }

    @Cacheable(cacheNames = "tag.byId", key = "#id")
    public TagResponseTo findById(Long id) {
        Tag tag = tagRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Tag not found with id: " + id));
        return tagMapper.entityToResponseTo(tag);
    }

    @Caching(
            put = @CachePut(cacheNames = "tag.byId", key = "#result.id"),
            evict = @CacheEvict(cacheNames = "tag.all", allEntries = true)
    )
    public TagResponseTo create(TagRequestTo request) {
        if (tagRepository.existsByName(request.getName())) {
            throw new IllegalArgumentException("Tag with name '" + request.getName() + "' already exists");
        }

        Tag tag = tagMapper.requestToToEntity(request);
        tag.setCreated(java.time.LocalDateTime.now());
        tag.setModified(java.time.LocalDateTime.now());

        Tag savedTag = tagRepository.save(tag);
        return tagMapper.entityToResponseTo(savedTag);
    }

    @Caching(
            put = @CachePut(cacheNames = "tag.byId", key = "#id"),
            evict = @CacheEvict(cacheNames = "tag.all", allEntries = true)
    )
    public TagResponseTo update(Long id, TagRequestTo request) {
        Tag existingTag = tagRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Tag not found with id: " + id));

        // Check if name is already taken by another tag
        if (!existingTag.getName().equals(request.getName()) &&
            tagRepository.existsByName(request.getName())) {
            throw new IllegalArgumentException("Tag with name '" + request.getName() + "' already exists");
        }

        tagMapper.updateEntityFromRequest(request, existingTag);
        existingTag.setModified(java.time.LocalDateTime.now());

        Tag updatedTag = tagRepository.save(existingTag);
        return tagMapper.entityToResponseTo(updatedTag);
    }

    @Caching(evict = {
            @CacheEvict(cacheNames = "tag.byId", key = "#id"),
            @CacheEvict(cacheNames = "tag.all", allEntries = true)
    })
    public void deleteById(Long id) {
        if (!tagRepository.existsById(id)) {
            throw new EntityNotFoundException("Tag not found with id: " + id);
        }
        tagRepository.deleteById(id);
    }
}