package com.blog.client;

import com.blog.dto.ReactionRequestTo;
import com.blog.dto.ReactionResponseTo;
import com.blog.exception.EntityNotFoundException;
import com.blog.kafka.ReactionKafkaOperation;
import com.blog.kafka.ReactionKafkaRequest;
import com.blog.kafka.ReactionKafkaResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Component
public class DiscussionClient {

    private final KafkaTemplate<String, ReactionKafkaRequest> kafkaTemplate;
    private final Map<String, CompletableFuture<ReactionKafkaResponse>> pendingResponses = new ConcurrentHashMap<>();

    private final String inTopic;

    public DiscussionClient(
            KafkaTemplate<String, ReactionKafkaRequest> kafkaTemplate,
            @Value("${app.kafka.in-topic:InTopic}") String inTopic
    ) {
        this.kafkaTemplate = kafkaTemplate;
        this.inTopic = inTopic;
    }

    @Cacheable(cacheNames = "reaction.all")
    public List<ReactionResponseTo> getAllReactions() {
        ReactionKafkaRequest request = baseRequest(ReactionKafkaOperation.GET_ALL);
        ReactionKafkaResponse response = sendAndAwait(request, "all");
        return response.getReactions() == null ? List.of() : response.getReactions();
    }

    @Cacheable(cacheNames = "reaction.byKey", key = "#country + ':' + #articleId + ':' + #id")
    public ReactionResponseTo getReactionById(String country, Long articleId, Long id) {
        ReactionKafkaRequest request = baseRequest(ReactionKafkaOperation.GET_BY_KEY);
        request.setCountry(country);
        request.setArticleId(articleId);
        request.setId(id);
        ReactionKafkaResponse response = sendAndAwait(request, keyForArticle(articleId));
        return response.getReaction();
    }

    @Cacheable(cacheNames = "reaction.byIdOnly", key = "#id")
    public ReactionResponseTo getReactionByIdOnly(Long id) {
        ReactionKafkaRequest request = baseRequest(ReactionKafkaOperation.GET_BY_ID_ONLY);
        request.setId(id);
        ReactionKafkaResponse response = sendAndAwait(request, "id:" + id);
        return response.getReaction();
    }

    @Cacheable(cacheNames = "reaction.byArticle", key = "#articleId")
    public List<ReactionResponseTo> getReactionsByArticleId(Long articleId) {
        ReactionKafkaRequest request = baseRequest(ReactionKafkaOperation.GET_BY_ARTICLE_ID);
        request.setArticleId(articleId);
        ReactionKafkaResponse response = sendAndAwait(request, keyForArticle(articleId));
        return response.getReactions() == null ? List.of() : response.getReactions();
    }

    @Cacheable(cacheNames = "reaction.byCountryArticle", key = "#country + ':' + #articleId")
    public List<ReactionResponseTo> getReactionsByCountryAndArticleId(String country, Long articleId) {
        ReactionKafkaRequest request = baseRequest(ReactionKafkaOperation.GET_BY_COUNTRY_AND_ARTICLE_ID);
        request.setCountry(country);
        request.setArticleId(articleId);
        ReactionKafkaResponse response = sendAndAwait(request, keyForArticle(articleId));
        return response.getReactions() == null ? List.of() : response.getReactions();
    }

    @Caching(evict = {
            @CacheEvict(cacheNames = "reaction.all", allEntries = true),
            @CacheEvict(cacheNames = "reaction.byArticle", key = "#request.articleId"),
            @CacheEvict(cacheNames = "reaction.byCountryArticle", key = "#request.country + ':' + #request.articleId")
    })
    public ReactionResponseTo createReaction(ReactionRequestTo request) {
        ReactionKafkaRequest kafkaRequest = baseRequest(ReactionKafkaOperation.CREATE);
        kafkaRequest.setReaction(request);
        kafkaRequest.setCountry(request.getCountry());
        kafkaRequest.setArticleId(request.getArticleId());

        kafkaTemplate.send(inTopic, keyForArticle(request.getArticleId()), kafkaRequest);

        ReactionResponseTo pending = new ReactionResponseTo();
        pending.setCountry(request.getCountry());
        pending.setArticleId(request.getArticleId());
        pending.setId(request.getId());
        pending.setContent(request.getContent());
        pending.setCreated(LocalDateTime.now());
        pending.setModified(LocalDateTime.now());
        pending.setStatus("PENDING");
        return pending;
    }

    @Caching(
            put = {
                    @CachePut(cacheNames = "reaction.byKey", key = "#country + ':' + #articleId + ':' + #id"),
                    @CachePut(cacheNames = "reaction.byIdOnly", key = "#id")
            },
            evict = {
                    @CacheEvict(cacheNames = "reaction.all", allEntries = true),
                    @CacheEvict(cacheNames = "reaction.byArticle", key = "#articleId"),
                    @CacheEvict(cacheNames = "reaction.byCountryArticle", key = "#country + ':' + #articleId")
            }
    )
    public ReactionResponseTo updateReaction(String country, Long articleId, Long id, ReactionRequestTo request) {
        ReactionKafkaRequest kafkaRequest = baseRequest(ReactionKafkaOperation.UPDATE);
        kafkaRequest.setCountry(country);
        kafkaRequest.setArticleId(articleId);
        kafkaRequest.setId(id);
        kafkaRequest.setReaction(request);
        ReactionKafkaResponse response = sendAndAwait(kafkaRequest, keyForArticle(articleId));
        return response.getReaction();
    }

    @Caching(
            put = {
                    @CachePut(cacheNames = "reaction.byKey", key = "#request.country + ':' + #request.articleId + ':' + #request.id"),
                    @CachePut(cacheNames = "reaction.byIdOnly", key = "#request.id")
            },
            evict = {
                    @CacheEvict(cacheNames = "reaction.all", allEntries = true),
                    @CacheEvict(cacheNames = "reaction.byArticle", key = "#request.articleId"),
                    @CacheEvict(cacheNames = "reaction.byCountryArticle", key = "#request.country + ':' + #request.articleId")
            }
    )
    public ReactionResponseTo updateReactionFromBody(ReactionRequestTo request) {
        ReactionKafkaRequest kafkaRequest = baseRequest(ReactionKafkaOperation.UPDATE);
        kafkaRequest.setCountry(request.getCountry());
        kafkaRequest.setArticleId(request.getArticleId());
        kafkaRequest.setId(request.getId());
        kafkaRequest.setReaction(request);
        ReactionKafkaResponse response = sendAndAwait(kafkaRequest, keyForArticle(request.getArticleId()));
        return response.getReaction();
    }

    @Caching(evict = {
            @CacheEvict(cacheNames = "reaction.byKey", key = "#country + ':' + #articleId + ':' + #id"),
            @CacheEvict(cacheNames = "reaction.byIdOnly", key = "#id"),
            @CacheEvict(cacheNames = "reaction.all", allEntries = true),
            @CacheEvict(cacheNames = "reaction.byArticle", key = "#articleId"),
            @CacheEvict(cacheNames = "reaction.byCountryArticle", key = "#country + ':' + #articleId")
    })
    public void deleteReaction(String country, Long articleId, Long id) {
        ReactionKafkaRequest kafkaRequest = baseRequest(ReactionKafkaOperation.DELETE);
        kafkaRequest.setCountry(country);
        kafkaRequest.setArticleId(articleId);
        kafkaRequest.setId(id);
        sendAndAwait(kafkaRequest, keyForArticle(articleId));
    }

    @Caching(evict = {
            @CacheEvict(cacheNames = "reaction.byIdOnly", key = "#id"),
            @CacheEvict(cacheNames = "reaction.byKey", allEntries = true),
            @CacheEvict(cacheNames = "reaction.all", allEntries = true),
            @CacheEvict(cacheNames = "reaction.byArticle", allEntries = true),
            @CacheEvict(cacheNames = "reaction.byCountryArticle", allEntries = true)
    })
    public void deleteReactionByIdOnly(Long id) {
        ReactionKafkaRequest kafkaRequest = baseRequest(ReactionKafkaOperation.DELETE_BY_ID_ONLY);
        kafkaRequest.setId(id);
        sendAndAwait(kafkaRequest, "id:" + id);
    }

    @KafkaListener(topics = "${app.kafka.out-topic:OutTopic}", groupId = "${spring.kafka.consumer.group-id:publisher}")
    public void onResponse(ReactionKafkaResponse response) {
        if (response == null || response.getCorrelationId() == null) {
            return;
        }
        CompletableFuture<ReactionKafkaResponse> future = pendingResponses.remove(response.getCorrelationId());
        if (future != null) {
            future.complete(response);
        }
    }

    private ReactionKafkaRequest baseRequest(ReactionKafkaOperation operation) {
        ReactionKafkaRequest request = new ReactionKafkaRequest();
        request.setCorrelationId(UUID.randomUUID().toString());
        request.setOperation(operation);
        return request;
    }

    private ReactionKafkaResponse sendAndAwait(ReactionKafkaRequest request, String key) {
        CompletableFuture<ReactionKafkaResponse> future = new CompletableFuture<>();
        pendingResponses.put(request.getCorrelationId(), future);

        kafkaTemplate.send(inTopic, key, request);

        ReactionKafkaResponse response;
        try {
            response = future.get(1, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            pendingResponses.remove(request.getCorrelationId());
            throw new IllegalArgumentException("Request interrupted");
        } catch (TimeoutException e) {
            pendingResponses.remove(request.getCorrelationId());
            throw new IllegalArgumentException("Timeout waiting for response");
        } catch (ExecutionException e) {
            pendingResponses.remove(request.getCorrelationId());
            throw new IllegalArgumentException("Error waiting for response");
        }

        if (response == null) {
            throw new IllegalArgumentException("Empty response");
        }
        if (!response.isSuccess()) {
            if ("ENTITY_NOT_FOUND".equals(response.getErrorCode())) {
                throw new EntityNotFoundException(response.getErrorMessage());
            }
            throw new IllegalArgumentException(response.getErrorMessage());
        }
        return response;
    }

    private String keyForArticle(Long articleId) {
        return articleId == null ? "0" : String.valueOf(articleId);
    }
}