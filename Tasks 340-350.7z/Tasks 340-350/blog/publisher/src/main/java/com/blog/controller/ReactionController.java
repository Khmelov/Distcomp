package com.blog.controller;

import com.blog.client.DiscussionClient;
import com.blog.dto.ReactionRequestTo;
import com.blog.dto.ReactionResponseTo;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@RestController
@RequestMapping("/api/v1.0/reactions")
public class ReactionController {

    private final DiscussionClient discussionClient;

    private static final AtomicLong ID_GENERATOR = new AtomicLong(1);

    public ReactionController(DiscussionClient discussionClient) {
        this.discussionClient = discussionClient;
    }

    @GetMapping
    public ResponseEntity<List<ReactionResponseTo>> getAllReactions() {
        List<ReactionResponseTo> reactions = discussionClient.getAllReactions();
        return ResponseEntity.ok(reactions);
    }

    @GetMapping("/{country}/{articleId}/{id}")
    public ResponseEntity<ReactionResponseTo> getReactionById(@PathVariable String country,
                                                              @PathVariable Long articleId,
                                                              @PathVariable Long id) {
        ReactionResponseTo reaction = discussionClient.getReactionById(country, articleId, id);
        return ResponseEntity.ok(reaction);
    }

    // Alternative endpoint for compatibility with test framework (when only id is known)
    @GetMapping("/{id}")
    public ResponseEntity<ReactionResponseTo> getReactionByIdOnly(@PathVariable Long id) {
        ReactionResponseTo reaction = discussionClient.getReactionByIdOnly(id);
        return ResponseEntity.ok(reaction);
    }

    @GetMapping("/article/{articleId}")
    public ResponseEntity<List<ReactionResponseTo>> getReactionsByArticleId(@PathVariable Long articleId) {
        List<ReactionResponseTo> reactions = discussionClient.getReactionsByArticleId(articleId);
        return ResponseEntity.ok(reactions);
    }

    @GetMapping("/country/{country}/article/{articleId}")
    public ResponseEntity<List<ReactionResponseTo>> getReactionsByCountryAndArticleId(@PathVariable String country,
                                                                                       @PathVariable Long articleId) {
        List<ReactionResponseTo> reactions = discussionClient.getReactionsByCountryAndArticleId(country, articleId);
        return ResponseEntity.ok(reactions);
    }

    @PostMapping
    public ResponseEntity<ReactionResponseTo> createReaction(@Valid @RequestBody ReactionRequestTo request) {
        // Ensure country has a default value if not provided
        if (request.getCountry() == null || request.getCountry().trim().isEmpty()) {
            request.setCountry("US");
        }

        if (request.getId() == null) {
            request.setId(ID_GENERATOR.getAndIncrement());
        }
        request.setStatus("PENDING");

        ReactionResponseTo createdReaction = discussionClient.createReaction(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdReaction);
    }

    @PutMapping("/{country}/{articleId}/{id}")
    public ResponseEntity<ReactionResponseTo> updateReaction(@PathVariable String country,
                                                             @PathVariable Long articleId,
                                                             @PathVariable Long id,
                                                             @Valid @RequestBody ReactionRequestTo request) {
        // Ensure country has a default value if not provided
        if (request.getCountry() == null || request.getCountry().trim().isEmpty()) {
            request.setCountry(country); // Use the country from URL path
        }
        ReactionResponseTo updatedReaction = discussionClient.updateReaction(country, articleId, id, request);
        return ResponseEntity.ok(updatedReaction);
    }

    // Alternative endpoint for compatibility with test framework
    @PutMapping
    public ResponseEntity<ReactionResponseTo> updateReactionFromBody(@Valid @RequestBody ReactionRequestTo request) {
        // Test framework sends ID in request body
        if (request.getId() == null) {
            return ResponseEntity.badRequest().build();
        }
        // Ensure country has a default value if not provided
        if (request.getCountry() == null || request.getCountry().trim().isEmpty()) {
            request.setCountry("US");
        }
        // Use the new endpoint that accepts request with ID in body
        ReactionResponseTo updatedReaction = discussionClient.updateReactionFromBody(request);
        return ResponseEntity.ok(updatedReaction);
    }

    @DeleteMapping("/{country}/{articleId}/{id}")
    public ResponseEntity<Void> deleteReaction(@PathVariable String country,
                                               @PathVariable Long articleId,
                                               @PathVariable Long id) {
        discussionClient.deleteReaction(country, articleId, id);
        return ResponseEntity.noContent().build();
    }

    // Alternative endpoint for compatibility with test framework (when only id is known)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteReactionByIdOnly(@PathVariable Long id) {
        discussionClient.deleteReactionByIdOnly(id);
        return ResponseEntity.noContent().build();
    }
}