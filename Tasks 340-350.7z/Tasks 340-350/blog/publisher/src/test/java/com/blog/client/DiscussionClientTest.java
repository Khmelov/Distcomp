package com.blog.client;

import com.blog.dto.ReactionRequestTo;
import com.blog.dto.ReactionResponseTo;
import com.blog.kafka.ReactionKafkaOperation;
import com.blog.kafka.ReactionKafkaRequest;
import com.blog.kafka.ReactionKafkaResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.core.KafkaTemplate;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class DiscussionClientTest {

    private KafkaTemplate<String, ReactionKafkaRequest> kafkaTemplate;
    private DiscussionClient discussionClient;

    @BeforeEach
    void setUp() {
        @SuppressWarnings("unchecked")
        KafkaTemplate<String, ReactionKafkaRequest> template = (KafkaTemplate<String, ReactionKafkaRequest>) mock(KafkaTemplate.class, withSettings().defaultAnswer(RETURNS_DEEP_STUBS));
        kafkaTemplate = template;
        discussionClient = new DiscussionClient(kafkaTemplate, "InTopic");

        when(kafkaTemplate.send(anyString(), anyString(), any(ReactionKafkaRequest.class)))
                .thenAnswer(inv -> {
                    ReactionKafkaRequest req = inv.getArgument(2);
                    ReactionKafkaResponse resp = new ReactionKafkaResponse();
                    resp.setCorrelationId(req.getCorrelationId());
                    resp.setOperation(req.getOperation());
                    resp.setSuccess(true);

                    if (req.getOperation() == ReactionKafkaOperation.GET_ALL) {
                        resp.setReactions(List.of(createSampleReaction()));
                    } else if (req.getOperation() == ReactionKafkaOperation.GET_BY_KEY
                            || req.getOperation() == ReactionKafkaOperation.GET_BY_ID_ONLY
                            || req.getOperation() == ReactionKafkaOperation.UPDATE) {
                        resp.setReaction(createSampleReaction());
                    }

                    discussionClient.onResponse(resp);
                    return CompletableFuture.completedFuture(null);
                });
    }

    @Test
    void getAllReactions_ShouldReturnReactionsList() {
        // When
        List<ReactionResponseTo> result = discussionClient.getAllReactions();

        // Then
        assertEquals(1, result.size());
        verify(kafkaTemplate).send(eq("InTopic"), eq("all"), any(ReactionKafkaRequest.class));
    }

    @Test
    void getReactionById_ShouldReturnReaction() {
        // When
        ReactionResponseTo result = discussionClient.getReactionById("US", 1L, 1L);

        // Then
        assertNotNull(result);
        assertEquals("US", result.getCountry());
        verify(kafkaTemplate).send(eq("InTopic"), eq("1"), any(ReactionKafkaRequest.class));
    }

    @Test
    void createReaction_ShouldReturnCreatedReaction() {
        // Given
        ReactionRequestTo request = new ReactionRequestTo("US", 1L, "Test content");
        request.setId(1L);

        // When
        ReactionResponseTo result = discussionClient.createReaction(request);

        // Then
        assertNotNull(result);
        assertEquals("PENDING", result.getStatus());
        verify(kafkaTemplate).send(eq("InTopic"), eq("1"), any(ReactionKafkaRequest.class));
    }

    @Test
    void updateReaction_ShouldReturnUpdatedReaction() {
        // Given
        ReactionRequestTo request = new ReactionRequestTo("US", 1L, "Updated content");

        // When
        ReactionResponseTo result = discussionClient.updateReaction("US", 1L, 1L, request);

        // Then
        assertNotNull(result);
        verify(kafkaTemplate).send(eq("InTopic"), eq("1"), any(ReactionKafkaRequest.class));
    }

    @Test
    void deleteReaction_ShouldCallDelete() {
        // When
        discussionClient.deleteReaction("US", 1L, 1L);

        // Then
        verify(kafkaTemplate).send(eq("InTopic"), eq("1"), any(ReactionKafkaRequest.class));
    }

    private ReactionResponseTo createSampleReaction() {
        return new ReactionResponseTo("US", 1L, 1L, "Test content",
                LocalDateTime.now(), LocalDateTime.now(), "APPROVE");
    }
}