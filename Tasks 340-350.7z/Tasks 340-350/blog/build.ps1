# PowerShell build script for Blog Application

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Building Blog Application Modules..." -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Make sure you have Maven and Java 21+ installed" -ForegroundColor Yellow
Write-Host ""

# Check Maven installation
Write-Host "Checking Maven installation..." -NoNewline
try {
    $mvnVersion = & mvn --version 2>$null
    if ($LASTEXITCODE -eq 0) {
        Write-Host "OK" -ForegroundColor Green
    } else {
        throw "Maven not found"
    }
} catch {
    Write-Host "ERROR" -ForegroundColor Red
    Write-Host "Maven is not installed or not in PATH" -ForegroundColor Red
    Write-Host "Please install Maven and add it to your PATH" -ForegroundColor Yellow
    Write-Host "Download from: https://maven.apache.org/download.cgi" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "Starting build..." -ForegroundColor Green
Write-Host ""

# Build all modules
& mvn clean package -DskipTests

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "Build completed successfully!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "JAR files created:" -ForegroundColor Cyan
    Write-Host "- publisher\target\publisher-0.0.1-SNAPSHOT.jar" -ForegroundColor White
    Write-Host "- discussion\target\discussion-0.0.1-SNAPSHOT.jar" -ForegroundColor White
    Write-Host ""
    Write-Host "To run Publisher module:" -ForegroundColor Yellow
    Write-Host "java -jar publisher\target\publisher-0.0.1-SNAPSHOT.jar" -ForegroundColor White
    Write-Host ""
    Write-Host "To run Discussion module:" -ForegroundColor Yellow
    Write-Host "java -jar discussion\target\discussion-0.0.1-SNAPSHOT.jar" -ForegroundColor White
    Write-Host ""
    Write-Host "Make sure PostgreSQL and Cassandra are running before starting the applications!" -ForegroundColor Red
    Write-Host ""
} else {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Red
    Write-Host "BUILD FAILED!" -ForegroundColor Red
    Write-Host "========================================" -ForegroundColor Red
    Write-Host "Please check the errors above and fix any issues." -ForegroundColor Yellow
    Write-Host "Common issues:" -ForegroundColor Yellow
    Write-Host "- Missing dependencies in POM files" -ForegroundColor White
    Write-Host "- Network connectivity issues" -ForegroundColor White
    Write-Host "- Java version compatibility" -ForegroundColor White
    Write-Host ""
}

Read-Host "Press Enter to exit"