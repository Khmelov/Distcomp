# Blog Application with Microservices Architecture

This application has been refactored into a multi-module architecture with separate services for content publishing and discussion management.

## Architecture Overview

### Publisher Module (Port 24110)
- **Database**: PostgreSQL
- **Responsibilities**:
  - Writer management
  - Article management
  - Tag management
  - Article-Tag relationships

### Discussion Module (Port 24130)
- **Database**: Cassandra
- **Responsibilities**:
  - Reaction/Comment management
  - Country-based data partitioning
  - Reaction moderation (APPROVE/DECLINE)

### Inter-service Transport (Kafka)

Publisher and Discussion exchange **Reaction** requests/responses via Kafka topics:

- **InTopic**: requests from `publisher` to `discussion`
- **OutTopic**: responses from `discussion` to `publisher`

## Prerequisites

1. **Java 21** or higher
2. **PostgreSQL** running on localhost:5432 with database `distcomp`
3. **Cassandra** running on localhost:9042 with keyspace `distcomp`
4. **Kafka** running on localhost:9092 (can be started with Docker, see below)
5. **Redis** running on localhost:6379 (can be started with Docker, see below)
6. **Maven 3.6+** for building (or use the provided build scripts)

## Quick Start

### Start Kafka (Docker)

Kafka is expected at `localhost:9092`.

```bash
docker network create kafkanet

docker run -d --network=kafkanet --name=zookeeper -e ZOOKEEPER_CLIENT_PORT=2181 -e ZOOKEEPER_TICK_TIME=2000 -p 2181:2181 confluentinc/cp-zookeeper

docker run -d --network=kafkanet --name=kafka -e KAFKA_ZOOKEEPER_CONNECT=zookeeper:2181 -e KAFKA_ADVERTISED_LISTENERS=PLAINTEXT://localhost:9092 -e KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR=1 -p 9092:9092 confluentinc/cp-kafka
```

Topics `InTopic` and `OutTopic` are used by default.

### Start Redis (Docker)

Redis is expected at `localhost:6379`.

```bash
docker run -d --name redis -p 6379:6379 redis
```

### Build the Project

#### Option 1: Using Build Scripts (Recommended)
```batch
# Windows batch script
build.bat

# Or PowerShell script
.\build.ps1
```

#### Option 2: Using Maven Directly
```bash
mvn clean package
```

### Start the Services

#### 1. Start Discussion Service (Cassandra)
```bash
java -jar discussion/target/discussion-0.0.1-SNAPSHOT.jar
```
- Port: 24130
- Database: Cassandra (keyspace: distcomp)
- API: http://localhost:24130/api/v1.0/reactions

#### 2. Start Publisher Service (PostgreSQL)
```bash
java -jar publisher/target/publisher-0.0.1-SNAPSHOT.jar
```
- Port: 24110
- Database: PostgreSQL (database: distcomp)
- API: http://localhost:24110/api/v1.0/

### Prerequisites Check

Before starting, ensure:
1. **Java 21+** is installed
2. **PostgreSQL** is running on localhost:5432 with database `distcomp`
3. **Cassandra** is running on localhost:9042 with keyspace `distcomp`
4. **Kafka** is running on localhost:9092
5. **Redis** is running on localhost:6379

### Service Health Check

After starting both services, you can check their status:
```batch
check-services.bat
```

This will verify that both services are accessible and responding.

## Database Setup

### PostgreSQL Setup
```sql
CREATE DATABASE distcomp;
CREATE SCHEMA distcomp;
-- The application will create tables automatically via Liquibase
```

### Cassandra Setup
```cql
-- Create keyspace (optional - Spring Data Cassandra will create it automatically)
CREATE KEYSPACE IF NOT EXISTS distcomp WITH replication = {'class':'SimpleStrategy', 'replication_factor':1};

-- Use the keyspace
USE distcomp;

-- Tables will be created automatically by Spring Data Cassandra
-- No manual schema creation needed
```

**Note:** The application uses Spring Data Cassandra for automatic schema management instead of Liquibase for Cassandra, as the Liquibase Cassandra extension has dependency resolution issues.

## Building the Application

### Option 1: Using Maven Wrapper (Recommended)

```bash
# Clone or navigate to the project directory
cd blog

# Build all modules (Unix/Linux/macOS)
./mvnw clean package

# Or on Windows
mvnw.cmd clean package
```

### Option 2: Using Build Scripts

```batch
# Windows batch script
build.bat

# Or PowerShell script
.\build.ps1
```

### Option 3: Using System Maven

If you have Maven installed system-wide:

```bash
mvn clean package
```

## Troubleshooting Build Issues

If you encounter build errors:

1. **Check Java Version:**
   ```bash
   java -version  # Should be Java 21+
   ```

2. **Check Maven Version:**
   ```bash
   mvn --version  # Should be Maven 3.6+
   ```

3. **Clean and Retry:**
   ```bash
   mvn clean
   mvn package -DskipTests
   ```

4. **If still failing, try with verbose output:**
   ```bash
   mvn clean package -X
   ```

5. **Clear Maven cache if dependency issues persist:**
   ```bash
   mvn dependency:purge-local-repository
   mvn clean package
   ```

6. **Force update dependencies:**
   ```bash
   mvn clean package -U
   ```

## Dependency Issues

### Liquibase Cassandra Extension

If you encounter issues with `liquibase-cassandra` dependency:
- The application has been configured to use Spring Data Cassandra for automatic schema management
- No Liquibase Cassandra extension is required
- Tables and keyspaces are created automatically when the application starts

### TestContainers

If TestContainers dependencies are not found:
- Ensure you have Java 11+ (TestContainers requires Java 11 minimum)
- The test dependencies are optional and won't affect production builds
- You can skip tests with: `mvn clean package -DskipTests`

## Running the Application

### Start Publisher Module
```bash
java -jar publisher/target/publisher-0.0.1-SNAPSHOT.jar
```
The publisher will be available at `http://localhost:24110`

### Start Discussion Module
```bash
java -jar discussion/target/discussion-0.0.1-SNAPSHOT.jar
```
The discussion service will be available at `http://localhost:24130`

## API Endpoints

### Publisher Module (localhost:24110)

#### Writers
- `GET /api/v1.0/writers` - Get all writers
- `GET /api/v1.0/writers/{id}` - Get writer by ID
- `POST /api/v1.0/writers` - Create writer
- `PUT /api/v1.0/writers/{id}` - Update writer
- `DELETE /api/v1.0/writers/{id}` - Delete writer

#### Articles
- `GET /api/v1.0/articles` - Get all articles
- `GET /api/v1.0/articles/{id}` - Get article by ID
- `POST /api/v1.0/articles` - Create article
- `PUT /api/v1.0/articles/{id}` - Update article
- `DELETE /api/v1.0/articles/{id}` - Delete article

#### Tags
- `GET /api/v1.0/tags` - Get all tags
- `GET /api/v1.0/tags/{id}` - Get tag by ID
- `POST /api/v1.0/tags` - Create tag
- `PUT /api/v1.0/tags/{id}` - Update tag
- `DELETE /api/v1.0/tags/{id}` - Delete tag

#### Reactions (proxied to discussion service)
- `GET /api/v1.0/reactions` - Get all reactions
- `GET /api/v1.0/reactions/{country}/{articleId}/{id}` - Get reaction by composite key
- `GET /api/v1.0/reactions/article/{articleId}` - Get reactions by article ID
- `POST /api/v1.0/reactions` - Create reaction
- `PUT /api/v1.0/reactions/{country}/{articleId}/{id}` - Update reaction
- `DELETE /api/v1.0/reactions/{country}/{articleId}/{id}` - Delete reaction

### Discussion Module (localhost:24130)

#### Reactions (direct access)
All the same endpoints as above, but with country-based partitioning.

## Reaction Statuses

- `PENDING`: returned immediately by `publisher` for `POST /reactions` (draft is sent to Kafka)
- `APPROVE` / `DECLINE`: assigned by `discussion` after moderation

## Redis Caching

Caching is implemented in the `publisher` module using Redis (Spring Cache).

- **TTL**: configured by `app.cache.ttl-seconds` (default `300` seconds)
- **Cached data**:
  - Writers: `GET /writers`, `GET /writers/{id}`
  - Articles: `GET /articles`, `GET /articles/{id}`
  - Tags: `GET /tags`, `GET /tags/{id}`
  - Reactions (Kafka-backed): `GET /reactions` and all reaction read endpoints
- **Invalidation**: on create/update/delete operations corresponding cache entries (and lists) are evicted/updated

## Testing

### Unit Tests
```bash
# Run tests for all modules
./mvnw test

# Run tests for specific module
./mvnw test -pl publisher
./mvnw test -pl discussion
```

### Integration Tests
Integration tests use Testcontainers for Cassandra testing. Make sure Docker is running.

### Test Coverage
The discussion module includes JaCoCo for test coverage reporting. Target coverage is 80%+.

```bash
# Generate coverage report
./mvnw test jacoco:report -pl discussion
# View report at: discussion/target/site/jacoco/index.html
```

## Key Changes Made

1. **Multi-module Architecture**: Split into `publisher` and `discussion` modules
2. **Database Migration**: Moved Reaction entity from PostgreSQL to Cassandra
3. **Data Model Changes**: Reaction now uses composite key (country, articleId, id) for Cassandra partitioning
4. **Service Communication**: Publisher communicates with Discussion via Kafka (`InTopic`/`OutTopic`) for `Reaction`
5. **Configuration Updates**: Separate ports and database configurations for each service
6. **Testing**: Comprehensive unit and integration tests with Testcontainers

## Cassandra Data Model
```cql
CREATE TABLE tbl_reaction (
    country text,        -- Partition key
    article_id bigint,   -- Clustering key 1
    id bigint,           -- Clustering key 2
    content text,
    created timestamp,
    modified timestamp,
    PRIMARY KEY ((country), article_id, id)
);
```

This partitioning strategy allows for efficient querying by country and article, supporting geographical distribution and scalability.