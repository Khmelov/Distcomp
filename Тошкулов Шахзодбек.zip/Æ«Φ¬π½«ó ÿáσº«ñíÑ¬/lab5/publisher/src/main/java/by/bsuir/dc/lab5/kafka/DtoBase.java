package by.bsuir.dc.lab5.kafka;

public interface DtoBase {
    Long id = 0L;

    public Long getId();
}
