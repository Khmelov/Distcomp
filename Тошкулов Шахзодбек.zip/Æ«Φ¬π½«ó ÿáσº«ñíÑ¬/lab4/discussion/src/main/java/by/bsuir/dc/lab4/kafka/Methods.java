package by.bsuir.dc.lab4.kafka;

public enum Methods {
    GET_BY_ID,
    GET_ALL,
    DELETE,
    UPDATE,
    CREATE
}
